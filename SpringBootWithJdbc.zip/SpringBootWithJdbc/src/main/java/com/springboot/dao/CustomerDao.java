package com.springboot.dao;

import java.util.List;

import com.springboot.model.Customer;

public interface CustomerDao {

	
	List<Customer> getCustomerData();
	void save(int id, String name, String sal);
	int edit(int id);
	void delete(int id);
	
}
