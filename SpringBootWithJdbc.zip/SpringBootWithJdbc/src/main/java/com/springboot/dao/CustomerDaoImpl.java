package com.springboot.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.springboot.model.Customer;

@Repository
public class CustomerDaoImpl implements CustomerDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Override
	public List<Customer> getCustomerData() {
        List<Customer> customers = new ArrayList<Customer>();
        List<Map<String, Object>> rows = jdbcTemplate.queryForList("select * from customers");

        for (Map<String, Object> row : rows) 
        {
             Customer customer = new Customer();
             customer.setId((int)row.get("id"));
             customer.setName((String)row.get("name"));
             customer.setSal((String)row.get("sal"));
             customers.add(customer);
         }
       return customers;	
	}

	@Override
	public void save(int id, String name, String sal) {
		
		jdbcTemplate.update("insert into customers (id, name, sal) values (?,?,?)", id, name, sal);
	}

	
	public int edit(int id){
		
		return jdbcTemplate.update("update table customers set name=?, sal=? where id=?",id);
		
	}

	@Override
	public void delete(int id) {
		
		 jdbcTemplate.update("delete from customers where id=?", id);
		
	}
}
