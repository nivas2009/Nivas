package com.springboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.springboot.model.Customer;
import com.springboot.service.CustomerService;

//@RestController	
@Controller
public class CustomerController {

	@Autowired
	private CustomerService service;
	
	
	@RequestMapping("/")
	public ModelAndView customerInformation() {
		
		List<Customer> customers = service.getCustomerData(); 
		
		ModelAndView mav = new ModelAndView("EmployeeList");
		
		mav.addObject("list", customers);
		
        return mav;
	
	}
	
	@RequestMapping("/AddCustomer")
	public ModelAndView addCustomer(@ModelAttribute("customer") Customer c){
		
		ModelAndView mav = new ModelAndView("EmployeeAdd");
		mav.addObject("customer", new Customer());
		return mav;
	}
	
	@RequestMapping("/save")
	public ModelAndView saveCustomer(@ModelAttribute("customer") Customer c, @RequestParam("id") int id, @RequestParam("name")String name, @RequestParam("sal") String sal){
		ModelAndView mav = new ModelAndView("EmployeeList");
		service.save(id, name, sal);
		mav.addObject("list", service.getCustomerData());
		return mav;	
	}
	
	
	@RequestMapping("/edit")
	public ModelAndView editCustomer(@RequestParam("id") int id){
		
		ModelAndView mav = new ModelAndView("EmployeeAdd");
		int i  = service.edit(id);
		if(i==0){
			
			throw new RuntimeException("id not found");
		}
		mav.addObject("list", service.getCustomerData());
		return mav;
		
	}
	
	
	@RequestMapping("/delete/{id}")
	public ModelAndView delete(@PathVariable("id") int id)
	{
		ModelAndView mav = new ModelAndView("EmployeeList");
		service.delete(id);
		mav.addObject("list", service.getCustomerData());
	    return mav;
	}
	
	
	
}
