package com.springboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.springboot.dao.CustomerDao;
import com.springboot.model.Customer;

@Service
public class CustomerServiceImpl implements CustomerService {

	

	@Autowired
	private CustomerDao dao ;
	
	@Transactional
	@Override
	public List<Customer> getCustomerData() {
		
		List<Customer> customers = dao.getCustomerData(); 
	
		return customers;
	}

	@Override
	public void save(int id, String name, String sal) {

		dao.save(id, name, sal);
		
	}

	@Override
	public int edit(int id) {

		return dao.edit(id);
	}

	@Override
	public void delete(int id) {
		dao.delete(id);
		
	}

}
